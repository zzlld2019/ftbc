package blockchain;/*
 * 아직 구현하지 못함 - 상의가 필요한 부분
 */
public class PushTx {
	private static Wallet managerWallet = new Wallet();
	
	public void chargeMoney() {
		
	}
	
	public void fundProject() {
		
	}
}
