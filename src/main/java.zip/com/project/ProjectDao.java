package com.project;

import java.security.PublicKey;
import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import vo.ProjectVO;


@Repository
public class ProjectDao {
	private static final Logger logger = LoggerFactory.getLogger(ProjectDao.class);
	
	@Autowired
	public SqlSessionTemplate sqlSessionTemplate = null;

	public List<ProjectVO> popularProject() {
		List<ProjectVO> popularProjects = null;
		return popularProjects;
	}

	public List<ProjectVO> recommnadProject() {
		List<ProjectVO> recommnadProjects = null;
		return recommnadProjects;
	}

	public List<ProjectVO> vergeofProject() {
		List<ProjectVO> vergeofProjects = null;
		return vergeofProjects;
	}

	public PublicKey getPublicKey(String mem_email) {
		PublicKey publicKey = sqlSessionTemplate.selectOne("getPublicKey",mem_email);
		return publicKey;
	}

	public List<ProjectVO> getFundedProject(List<String> projectCodes) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public List<ProjectVO> getMyProjects(String mem_email) {
		// TODO Auto-generated method stub
		return null;
	}
	
	public ProjectVO getProjectDetail(String projectCode) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
