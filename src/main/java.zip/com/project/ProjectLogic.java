package com.project;

import java.security.PublicKey;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import blockchain.Block;
import blockchain.BlockChain;
import blockchain.Output;
import blockchain.Project;
import blockchain.Transaction;
import blockchain.Wallet;
import blockchain.util.Base64Conversion;
import blockchain.util.CommonSet;
import vo.ProjectVO;

@Service
public class ProjectLogic {
	private static final Logger logger = LoggerFactory.getLogger(ProjectLogic.class);
	@Autowired
	ProjectDao projectDao = null;
	
	public BlockChain getBlockChain() {
		BlockChain blockChain = null;
		try {
			String blockchain64 = Base64Conversion.importChain("FTBCChain","C:\\Users\\kosmo_03\\Desktop\\FTBC\\test (1)\\");
			blockChain = (BlockChain) Base64Conversion.decodeBase64(blockchain64);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return blockChain;
		
	}
	//메인 페이지에 뿌릴 프로젝트들 가져오기 
	public Map<String, Object>getMainProjects() {
		Map<String, Object> mainProjects = new HashMap<>();
		
		//VO로 바꾸거나 그냥 Map 쓰거나
		// DB에서 가져와야할 것 프로젝트명, 프로젝트 올린사람 닉네임, 목표금액, 마감일
		List<ProjectVO> popularProjects = projectDao.popularProject(); //인기 프로젝트
		List<ProjectVO> recommnadProjects = projectDao.recommnadProject(); //추천 프로젝트 
		List<ProjectVO> vergeofProjects = projectDao.vergeofProject(); //성공임박 프로젝트
		
		/*
		 * DB에서 가져온 정보로 BlockChain에 있는 데이터 가져와야함.
		 * 블록체인에서 가져와야할 정보: 프로젝트 모인 금액
		 */
		
		//프로젝트 리스트들로 putFundedMoney돌려서 블록체인에있는 펀딩금액 데이터 넣어서 Map에 담아줌.
		mainProjects.put("popularProject", putFundedMoney(popularProjects));
		mainProjects.put("recommnadProject", putFundedMoney(recommnadProjects));
		mainProjects.put("vergeofProject", putFundedMoney(vergeofProjects));
		
		return mainProjects;
	}
	
	//프로젝트 별로 펀딩 금액 가져오기
	public List<ProjectVO> putFundedMoney(List<ProjectVO> projectList) {
		CommonSet commonset = CommonSet.getInstance();
		//금액까지 넣은 map을 넣을 리스트
		List<ProjectVO> tempList = new Vector();
		//펀딩 금액
		int fundedMoney = 0;
		
		/*
		 * 1. 파라미터로 받아온 프로젝트 리스트만큼 for문 돌려서 프로젝트 코드들 가져옴
		 * 2. CommonSet에 있는 projectWallets 크기 만큼 for문 돌려서 1번에서 가져온
		 *    프로젝트코드로 해당 프로젝트의 projectWallet 가져옴
		 * 3. 2번에서 가져온 projectWallet의 UTXOs 만큼 for문 돌려서 
		 * 	  UTXO의 output의 value를 FundedMoney변수에 ++
		 * 4. 1번에서 가져온 tempProject에 FundedMoney추가
		 * 5. tempList에 tempProject넣고 리턴
		 */
		for(int i=0; i<projectList.size();i++) {
			ProjectVO tempProject = projectList.get(i);
			String projectCode = tempProject.getProject_code();
			Map<String, Wallet> projectWallets = commonset.projectWallets;
			
			Object keys[] = projectWallets.keySet().toArray();
			for(int j=0;j<keys.length;j++) { 
				if(projectCode.equals(keys[j].toString())){
					Wallet projectWallet = projectWallets.get(keys[j]);
					Map<String, Output> UTXOs = projectWallet.UTXOs;
					Object UTXO_keys[] = UTXOs.keySet().toArray();
					for(int k=0;k<UTXO_keys.length;k++) {
						Output output = UTXOs.get(UTXO_keys[k]);
						fundedMoney =+ output.value;
					}
					//end of UTXO_keys for
				}
				// end of if
			}
			// end of projectWallets keys for
			tempProject.setFundedMoney(fundedMoney);
			tempList.add(tempProject);
		}
		// end of projectList for
		return tempList;
	}
	// end of putFundedMoney

	
	//내가 펀딩한 프로젝트들 가져오기 
	public List<ProjectVO> getFundedProjects(String mem_email) {
		//내가 펀딩한 프로젝트 담을 리스트
		List<ProjectVO> fundedProjects = new ArrayList<>();
		//내가 펀딩한 프로젝트의 프로젝트 코드들
		List<String> projectCodes = new ArrayList<>();
		//내 퍼블릭키 
		PublicKey my_publicKey = projectDao.getPublicKey(mem_email);
		CommonSet commonset = CommonSet.getInstance();
		BlockChain blockChain = getBlockChain();
		/*
		 * 1. 로컬에서 가져온 블록체인의 사이즈 만큼 for문 돌려서 Block을 뽑아냄
		 * 2. 블럭의 transactions 사이즈만큼 for문을 돌려서 트랜잭션을 뽑아냄
		 * 3. 트랜잭션의 sender가 내 공개키와 같을경우 reciepient을 가져옴 
		 * 4. 3번에서 가져온 reciepient(PublicKey)로 CommonsSet의 projects에서
		 * 	  프로젝트 코드를 가져온다음 proejectCodes 리스트에 담음.
		 * 5. proejectCodes를 파라미터로 보내서 DB에서 해당 프로젝트의 정보들을 가져옴.
		 */
		for(int i=0;i<blockChain.blockChain.size();i++) {
			Block block = blockChain.blockChain.get(i);
			for(int j=0;j<block.transactions.size();j++){
				Transaction transaction = block.transactions.get(j);
				PublicKey funded_publicKey = null;
				if(my_publicKey.equals(transaction.sender)){
					funded_publicKey = transaction.reciepient;
					String projectCode = commonset.projects.get(funded_publicKey).projectCode;
					projectCodes.add(projectCode);
				}
			}
		}
		
		fundedProjects = putFundedMoney(projectDao.getFundedProject(projectCodes));
		
		return fundedProjects;
	}
	
	//내가 만든 프로젝트들 가져오기
	public List<ProjectVO> getMyProjects(String mem_email) {
		List<ProjectVO> myProjects = new ArrayList<>();
		myProjects = putFundedMoney(projectDao.getMyProjects(mem_email));
		return myProjects;
	}
	
	//프로젝트 상세보기 
	public ProjectVO getProjectDetail(String projectCode) {
		ProjectVO projectDetail = projectDao.getProjectDetail(projectCode);
		//상세보기할 프로젝트의 공개키
		PublicKey project_key = null;
		try {
			project_key = (PublicKey)Base64Conversion.decodeBase64(projectDetail.getPj_publickey());
		} catch (Exception e) {
			e.printStackTrace();
		}
		// 상세보기할 프로젝트의 후원자 수 담을 변수
		int sup_num = 0;
		BlockChain blockChain = getBlockChain();
		/*
		 * 후원자 명수 가져오기
		 * 1. 로컬에서 가져온 블록체인의 사이즈 만큼 for문 돌려서 Block을 뽑아냄
		 * 2. 블럭의 transactions 사이즈만큼 for문을 돌려서 트랜잭션을 뽑아냄
		 * 3. 트랜잭션의 reciepient가 DB에서 가져온 프로젝트의 공개키와 같을경우
		 *    후원자 명 수 ++
		 * 4. projectDetail 맵에 후원자 수 도 put
		 */
		for(int i=0;i<blockChain.blockChain.size();i++) {
			Block block = blockChain.blockChain.get(i);
			for(int j=0;j<block.transactions.size();j++){
				Transaction transaction = block.transactions.get(j);
				if(project_key.equals(transaction.reciepient)) {
					sup_num ++;
				}
			}
		}
		projectDetail.setSupport_num(sup_num);
		return projectDetail;
	}
	
	
	
}
