package com.project;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import blockchain.BlockChain;
import blockchain.Project;
import blockchain.util.Base64Conversion;
import blockchain.util.CommonSet;
import vo.ProjectVO;


@Controller
@RequestMapping("/Project/*")
public class ProjectController  {
	private static final Logger logger = LoggerFactory.getLogger(ProjectController.class);

	@Autowired
	ProjectLogic projectLogic = null;
	
	/*
	 * 프로젝트아이디로 프로젝트 현재 금액 가져오기
	 * 프로젝트 아이디로 프로젝트 현재 후원자 가져오기 
	 * 후원자 아이디 혹은 공개키로 후원한 프로젝트 가져오기
	 */
	
	@GetMapping(value="getFundedProject")
	public String getFundedPProject(@RequestParam String mem_email, Model mod) {
		logger.info(" getFundedProject 호출");
		//내가 펀딩한 프로젝트
		List<ProjectVO> fundedProjects = projectLogic.getFundedProjects(mem_email);
		mod.addAttribute("FundedProjects",fundedProjects);
		return "forward:FTBC_FundedProjectList.jsp";
		
	}
	
	@GetMapping(value="getMyProject")
	public String getMyProject(@RequestParam String mem_email, Model mod) {
		logger.info(" getMyProject 호출");
		List<ProjectVO> myProjects = projectLogic.getMyProjects(mem_email);
		
		//내가 만든 프로젝트 
		
		return "forward:FTBC_myProjectList.jsp";
		
	}
	
	@GetMapping(value="getMainProject")
	public String getMainProject(Model mod) {
		logger.info("내가 펀딩한 프로젝트 getMainProject 호출");
		//메인뷰에 뿌릴  인기, 추천, 성공임박 프로젝트 
		Map<String, Object> mainProjects = projectLogic.getMainProjects();
		mod.addAttribute("mainProjects",mainProjects);
		return  "forward:FTBC_MainList.jsp";
	}
	
	@GetMapping(value="projectDetail")
	public String getProjectDetail(@RequestParam String projectCode, Model mod) {
		logger.info("projectDetail 호출");
		ProjectVO projectDetail = projectLogic.getProjectDetail(projectCode);
		mod.addAttribute("projectDetail", projectDetail);
		return "forward:FTBC_DetailList.jsp";
		
	}
	
}
