package com.member;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.chain.ChainLogic;

import vo.MemberVO;

@Service
public class MemberLogic {
	private static final Logger logger = LoggerFactory.getLogger(MemberLogic.class);
	
	@Autowired
	MemberDao memberDao = null;

	public String memberLogin(MemberVO mVO) {
		logger.info("Logic�샇異�");
		String result = null;
		result = memberDao.memberLogin(mVO);
		return result;
	}

	public int memberJoin(MemberVO mVO) {
		int result = 0;
		result = memberDao.memberJoin(mVO);
		return result;
	}
}
