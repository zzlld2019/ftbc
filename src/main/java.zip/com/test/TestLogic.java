package com.test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;


@Service
public class TestLogic {
	private static final Logger logger = LoggerFactory.getLogger(TestLogic.class);
}
