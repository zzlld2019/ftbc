package com.chain;

import java.io.IOException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


import blockchain.Block;
import blockchain.BlockChain;
import blockchain.Wallet;
import blockchain.util.Base64Conversion;
import blockchain.util.CommonSet;
import blockchain.util.StringUtil;

@Controller
@RequestMapping("/chain/*")
public class ChainController {
	private static final Logger logger = LoggerFactory.getLogger(ChainController.class);
	
	@Autowired
	ChainLogic chainLogic = null;
	// 5분 마다 생성되는 블록
	private Block newBlock = null;
	
	@RequestMapping(value="addTransaction")
	public String addTransaction(@RequestParam Map<String,Object> pMap) throws Exception {
		logger.info("addTransaction 호출");
		//사용자 로컬에서 블록체인 파일 import해옴
		String blockchain64 = Base64Conversion.importChain("FTBCChain","C:\\Users\\kosmo_03\\Desktop\\FTBC\\test (1)\\");
			
		//blockchain, publickey, privatekey 디코딩. chain도  import해도 됨.
		BlockChain blockChain = (BlockChain) Base64Conversion.decodeBase64(blockchain64);
		PublicKey publicKey = (PublicKey) Base64Conversion.decodeBase64(pMap.get("puk").toString());
		PrivateKey privateKey = (PrivateKey) Base64Conversion.decodeBase64(pMap.get("prk").toString());
		
		//펀딩하는 사람 임시 지갑
		Wallet tempWallet = new Wallet();
		
		//펀딩 금액
		int amount = Integer.parseInt(pMap.get("paid_amount").toString());
		
		//펀딩하는 프로젝트의 키
		CommonSet commonSet = CommonSet.getInstance();
		Wallet projectWallet = commonSet.getProjectWallet("프로젝트 아이디");
		//프로젝트 아이디는 db에서 꺼내오자.
		
		PublicKey projectKey =  projectWallet.publicKey;
		

		//// [거래가 일어날 때 마다 newBlock에 addTransaction] ////
		Block block = newBlock; //생성되어있는 블록 가져와야함
		/*
		 * 1. ManagerWallet -> sender wallet 
		 * block.addtransaction
		 * 2. sender wallet -> reciepient wallet
		 * block.addctransacton
		 * */
		
		
		Wallet managerWallet = commonSet.managerWallet; //genesisblock 만들때 generate keypair 해줘야함.
		
		//매니저 -> 펀딩하는 사람
		block.addTransaction(blockChain,managerWallet.sendFunds(blockChain,publicKey, amount));
		
		//펀딩하는 사람 -> 프로젝트
		block.addTransaction(blockChain,tempWallet.sendFunds(blockChain,projectKey, amount));
		
		//// [거래가 일어날 때 마다 newBlock에 addTransaction] ////
		return "redirect:Fund_Success.jsp";
	}
	
	
}
