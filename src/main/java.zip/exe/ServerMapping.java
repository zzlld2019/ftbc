package exe;

public class ServerMapping {
	MsgServer msgServer = null;
	FileServer fileServer = null;
	TimeThread timeThread = null;
	
	public ServerMapping() {
		msgServer = new MsgServer(this);
		fileServer = new FileServer(this);
		timeThread = new TimeThread(this);
	}
	public static void main(String[] args) {
		new ServerMapping();
	}
}
