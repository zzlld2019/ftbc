package exe;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import com.google.gson.Gson;

import exe.util.Path;
import exe.util.Protocol;

public class FileServerThread extends Thread {
	FileServer fserver = null;
	InputStream in = null;
	//
	FileOutputStream fout = null;
	//
	OutputStream out = null;
	FileInputStream fin = null;
	DataOutputStream dout = null;
	DataInputStream din = null;
	String dataSize = null;
	String changeName = null;
	String loginID = null;

	public FileServerThread(FileServer fserver) {
		this.fserver = fserver;
		try {
			in = fserver.fcSocket.getInputStream();
			din = new DataInputStream(in);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public void msgServerSend(String msg) {
		try {
			// 파일 무결성 검사를 위한 통신
			Map<String, MsgServerThread> msgMaps = fserver.serverMapping.msgServer.globalMaps;
			for(int i=0;i<msgMaps.size();i++) {
				Object keys[] = msgMaps.keySet().toArray();
				if(loginID.equals(keys[i])) {
					MsgServerThread msgThread = msgMaps.get(keys[i]);
					msgThread.oos.writeObject(msg);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Override
	public void run() {
		boolean isStop = false;
		StringTokenizer stz = null;
		int protocol = 0;
		while (!isStop) {
			try {
				String msg = din.readUTF();
				if (msg != null && msg.length() > 0) {
					fserver.jta_log.append("메세지 : " + msg + "\n");
					stz = new StringTokenizer(msg, "|");
					protocol = Integer.parseInt(stz.nextToken());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			switch (protocol) {
			case Protocol.CHAIN_SYNC_UPLOAD: {
				try {
					String loginID = stz.nextToken();
					fserver.jta_log.append("FILE_UPLOAD_START의 loginID : "+loginID);
					// 파일 공유 폴더에 올릴 때 : 클라에서 준 파일을 다운로드 할 경우
					int data = din.readInt();
					String filename = din.readUTF();
					fserver.jta_log.append("클라에서 준 : " + filename + "\n");
					File file = new File(Path.CLIENT_CHAIN_PATH+ filename);
					// * 파일
					out = new FileOutputStream(file);
					
					int datas = data;
					byte[] buffer = new byte[1024];
					int len;
					
					for (; data > 0; data--) {
						len = in.read(buffer);
						out.write(buffer, 0, len);
					}
					
					changeName = file.getName();
					dataSize = String.valueOf(datas) + "kbps";
					
					fserver.jta_log.append("파일 이름 : " + changeName + ", 파일 사이즈 : " + dataSize + "\n");
					fserver.jta_log.append("약" + datas + "kbps \n");
					
					this.msgServerSend(Protocol.CHAIN_AUTHENTICATE_START
									+Protocol.seperator+loginID);
					out.flush();
					out.close();
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					try {
						if(fserver.fcSocket!=null) {
							fserver.jta_log.append(fserver.fcSocket.toString()+" 종료되었습니다. \n");
							fserver.fcSocket.close();
						}
						if(isStop == false) isStop = true;
					} catch (Exception e2) {
						e2.printStackTrace();
					}
				}
			}
				break;
			// 서버의 체인을 클라이언트에 다운로드 시킬 때
			case Protocol.CHAIN_SYNC_DOWNLOAD: {
				try {
					String loginID = stz.nextToken();
					fserver.jta_log.append("파일다운로드_로그인아이디 : " + loginID + "\n");
					out = fserver.fcSocket.getOutputStream();
					dout = new DataOutputStream(out);
					dout.writeUTF(Protocol.CHAIN_SYNC_DOWNLOAD + Protocol.seperator + "시작");
					// 체인을 가져옴
					fin = new FileInputStream(new File(Path.SERVER_ABSOLUTE_PATH));
					byte[] buffer = new byte[1024];
					int len = 0;
					int data = 0;

					while ((len = fin.read(buffer)) > 0) {
						data++;
					}
					// int datas = data;
					fin.close();
					fin = new FileInputStream(Path.SERVER_ABSOLUTE_PATH);
					
					dout.writeInt(data);
					// fileName
					dout.writeUTF(loginID+"Chain.ftbc");

					len = 0;
					for (; data > 0; data--) {
						len = fin.read(buffer);
						out.write(buffer, 0, len);
					}
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					try {
						if(dout!=null) dout.close();
						if(out!=null) out.close();
						if(fserver.fcSocket!=null) {
							fserver.jta_log.append(fserver.fcSocket.toString()+" 종료되었습니다. \n");
							fserver.fcSocket.close();
						}
						if(isStop == false) isStop = true;
					} catch (Exception e2) {
						e2.printStackTrace();
					}
				}
			}////////////////end of FILE DOWNLOAD
			break;
			case Protocol.AUTOSYNC_CHAIN_UPLOAD: {
				try {
					String loginID = stz.nextToken();
					fserver.jta_log.append("FILE_UPLOAD_START의 loginID : "+loginID);
					// 파일 공유 폴더에 올릴 때 : 클라에서 준 파일을 다운로드 할 경우
					int data = din.readInt();
					String filename = din.readUTF();
					fserver.jta_log.append("클라에서 준 : " + filename + "\n");
					File file = new File(Path.CLIENT_CHAIN_PATH+ filename);
					// * 파일
					out = new FileOutputStream(file);
					
					int datas = data;
					byte[] buffer = new byte[1024];
					int len;
					
					for (; data > 0; data--) {
						len = in.read(buffer);
						out.write(buffer, 0, len);
					}
					
					changeName = file.getName();
					dataSize = String.valueOf(datas) + "kbps";
					
					fserver.jta_log.append("파일 이름 : " + changeName + ", 파일 사이즈 : " + dataSize + "\n");
					fserver.jta_log.append("약" + datas + "kbps \n");
					fserver.jta_log.append("AUTOSYNC_CHAIN_UPLOAD 클라 체인 업로드 완료!\n");
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					try {
						if(fserver.fcSocket!=null) {
							fserver.jta_log.append(fserver.fcSocket.toString()+" 종료되었습니다. \n");
							fserver.fcSocket.close();
						}
						if(isStop == false) isStop = true;
					} catch (Exception e2) {
						e2.printStackTrace();
					}
				}
			}
			break;
			}
		}
	}
}
