package exe;

import java.awt.Color;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import exe.util.Path;


public class MsgServer extends JFrame implements Runnable {
	ServerSocket sSocket = null;
	Socket cSocket = null;
	ServerMapping serverMapping = null;
	MsgServerThread mst = null;
	Map<String, MsgServerThread> globalMaps = new HashMap<>();
	JTextArea jta_log = new JTextArea();
	JScrollPane jsp_log = new JScrollPane(jta_log);
	boolean isStop = false;
	
	public MsgServer(ServerMapping serverMapping) {
		this.initDisplay();
		this.serverMapping = serverMapping;
		new Thread(this).start();
	}
	
	public void initDisplay() {
		jta_log.setEditable(false);
		jta_log.getCaret().setSelectionVisible(true);
		jta_log.setCaretColor(Color.white);
		jta_log.getCaret().setBlinkRate(300);
		jta_log.getCaret().setVisible(true);
		jta_log.setForeground(Color.white);
		jta_log.setBackground(Color.black);
		jta_log.append("Microsoft Windows [Version 10.0.17763.615]"+"\n");
		jta_log.append("(c) 2018 Microsoft Corporation. All rights reserved."+"\n");
        jta_log.append("\n");
        jta_log.append("C:\\Server>"+ "\n");
		this.add(jsp_log);
		this.setTitle("메세지 서버 측 로그 출력창");
		this.setSize(500, 500);
		this.setVisible(true);
	}

	@Override
	public void run() {
		try {
			sSocket = new ServerSocket(Path.MSG_SERVER_PORT);
			jta_log.setCaretPosition(jta_log.getDocument().getLength());
			while(!isStop) {
				jta_log.append("MsgServer wating...\n");
				cSocket = sSocket.accept();
				mst = new MsgServerThread(this);
				mst.start();
				jta_log.append("MsgServerThread 접속: "+cSocket.toString()+"\n");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
