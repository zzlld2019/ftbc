package exe;


import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JLabel;

import blockchain.BlockChain;
import blockchain.util.Base64Conversion;
import blockchain.util.MajorityElement;
import exe.util.Path;
import exe.util.Protocol;


public class TimeThread extends JFrame implements Runnable {
    private static int seconds = 0;
    private static boolean notify;
    JLabel jl;
    ServerMapping serverMapping = null;
    Thread thread = null;
    
    public TimeThread(ServerMapping serverMapping) {
    	this.initDisplay();
    	this.serverMapping = serverMapping;
    	new Thread(this).start();
//    	thread = new Thread(this);
	}
    public void initDisplay() {
    	jl = new JLabel();
    	jl.setHorizontalAlignment(JLabel.CENTER);
    	this.add(jl);
    	this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("타임 스레드 측 시간");
		this.setSize(350, 100);;
		this.setVisible(true);
    }
    
    
    
    // 과반수가 넘는 체인 채택하는 메소드
    public void majorityChain() {
    	try {
        	serverMapping.msgServer.jta_log.append("블록추가!!!!!!!!\n");
        	// 클라이언트 체인의 사이즈가 서버 체인의 사이즈와 같은(:과반수 알고리즘을 적용할 수 있는 체인)만 리스트에 넣어줌.
        	List<BlockChain> syncBlockChain = null;
        	syncBlockChain = new Vector<>();
        	String base64Chain = null;
        	BlockChain clientChain = null;
        	// 서버의 체인을 가져옴
        	String serverBase64 = Base64Conversion.importChain("FTBC", Path.SERVER_CHAIN_PATH); 
        	BlockChain serverChain = (BlockChain) Base64Conversion.decodeBase64(serverBase64);
        	// 서버의 체인도 넣어줌
        	syncBlockChain.add(serverChain);
        	Map<String, MsgServerThread> globalMaps = serverMapping.msgServer.globalMaps;
        	Object keys[] = globalMaps.keySet().toArray();
        	for(int i=0;i<globalMaps.size();i++) {
        		MsgServerThread msgServerThread = globalMaps.get(keys[i]);
        		if(msgServerThread.isCheck) { // 자동 동기화 체크박스가 선택되있으면
        			//클라이언트의 체인 업로드
        			msgServerThread.send(Protocol.AUTOSYNC_UPLOAD
        					+Protocol.seperator);
        			//# 바뀌어야되는 코드
        			Thread.sleep(2000);
    				base64Chain = Base64Conversion.importChain(msgServerThread.loginID, Path.CLIENT_CHAIN_PATH);
    				clientChain = (BlockChain) Base64Conversion.decodeBase64(base64Chain);
    				// 체인이 무결하다면
    				if(clientChain.isChainValid()) {
    					// 서버의 체인과 사이즈와 UTXOs가 같고 체인이 무결하다면
    					serverChain.syncUTXOs();
    					clientChain.syncUTXOs();
    					// && (clientChain.UTXOs.size() == serverChain.UTXOs.size()) 
    					if( (clientChain.blockChain.size() == serverChain.blockChain.size())) {
    						syncBlockChain.add(clientChain);
    					}// 체인과 UTXO 사이즈가 같을 경우 if
    				}////// 클라이언트 체인 밸리드 if
				}////////// 자동 동기화 버튼 if
    		}////////////// 과반수 프로그램을 돌릴 체인들만 모으기 끝
        	MajorityElement majorityElement = new MajorityElement();
        	BlockChain sharedChain = majorityElement.majorityElement(syncBlockChain);
        	if(sharedChain.isChainValid()) {
        		serverMapping.msgServer.jta_log.append("#과반수로 채택한 체인이 무결합니다!\n");
        		serverMapping.msgServer.jta_log.append("과반수 체인 이름 : "+sharedChain.name);
        	}
        	// 과반수로 채택된 체인 저장
        	String sharedBase64 = Base64Conversion.encodeChain(sharedChain);
        	Base64Conversion.saveChain(sharedBase64, Path.SERVER_CHAIN_PATH, "FTBC");
    	} catch (Exception e) {
    		e.printStackTrace();
		}
    }
    @Override
    public void run() {
        while(true){
        	jl.setText(seconds+"초");
            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            seconds++;
            if(seconds == 60) {
            	// 트랜잭션 애드된 새 블록을 받아야지
            	
            	seconds = 0;
            	// addBlock이 되는 부분 추가
            	this.majorityChain();
        	}
        }
    }
}
