package exe.util;

public class Path {
	public static final String SERVER_IP = "192.168.0.211";
	public static final int FILE_SERVER_PORT = 9004;
	public static final int MSG_SERVER_PORT = 9005;
	
	public static final String SERVER_CHAIN_PATH = "C:\\FTBC_server\\chain\\";
	public static final String CLIENT_CHAIN_PATH = "C:\\FTBC_server\\chain\\client\\";
	public static final String SERVER_ABSOLUTE_PATH = "C:\\FTBC_server\\chain\\FTBCChain.ftbc";
//	public static final String SERVER_CHAIN_PATH = "C:\\FTBC_server\\";
}

