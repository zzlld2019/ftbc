package vo;

public class ProjectVO {
	//DB에 있는것
	private String project_code = null;
	private String subcat_code = null;
	private String pj_nowmoney = null;
	private String mem_email = null;
	private String pj_isedit = null;
	private String pj_publickey = null;
	private String pj_privatekey = null;
	private String pj_account = null;
	private String pj_stat = null;
	private String pj_issuccess = null;
	
	//체인에서 가져와야하는것
	private int fundedMoney = 0;
	private int support_num = 0;

	public String getProject_code() {
		return project_code;
	}

	public void setProject_code(String project_code) {
		this.project_code = project_code;
	}

	public String getSubcat_code() {
		return subcat_code;
	}

	public void setSubcat_code(String subcat_code) {
		this.subcat_code = subcat_code;
	}

	public String getPj_nowmoney() {
		return pj_nowmoney;
	}

	public void setPj_nowmoney(String pj_nowmoney) {
		this.pj_nowmoney = pj_nowmoney;
	}

	public String getMem_email() {
		return mem_email;
	}

	public void setMem_email(String mem_email) {
		this.mem_email = mem_email;
	}

	public String getPj_isedit() {
		return pj_isedit;
	}

	public void setPj_isedit(String pj_isedit) {
		this.pj_isedit = pj_isedit;
	}

	public String getPj_publickey() {
		return pj_publickey;
	}

	public void setPj_publickey(String pj_publickey) {
		this.pj_publickey = pj_publickey;
	}

	public String getPj_privatekey() {
		return pj_privatekey;
	}

	public void setPj_privatekey(String pj_privatekey) {
		this.pj_privatekey = pj_privatekey;
	}

	public String getPj_account() {
		return pj_account;
	}

	public void setPj_account(String pj_account) {
		this.pj_account = pj_account;
	}

	public String getPj_stat() {
		return pj_stat;
	}

	public void setPj_stat(String pj_stat) {
		this.pj_stat = pj_stat;
	}

	public String getPj_issuccess() {
		return pj_issuccess;
	}

	public void setPj_issuccess(String pj_issuccess) {
		this.pj_issuccess = pj_issuccess;
	}

	public int getFundedMoney() {
		return fundedMoney;
	}

	public void setFundedMoney(int fundedMoney) {
		this.fundedMoney = fundedMoney;
	}

	public int getSupport_num() {
		return support_num;
	}

	public void setSupport_num(int support_num) {
		this.support_num = support_num;
	}

}
