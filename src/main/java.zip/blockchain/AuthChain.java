package blockchain;

import java.io.Serializable;

import blockchain.util.Base64Conversion;
import exe.util.Path;

/*
 * 체인의 무결성을 점검하는 클래스
 */
public class AuthChain implements Serializable {
	private static final long serialVersionUID = -1084446089912098307L;
	public BlockChain serverChain = null;
	public BlockChain clientChain = null;

	/***************
	 * 무조건 선행 되어야 하는 메소드
	 * @param loginID
	 * @throws Exception
	 */
	public void decodeInitialization(String loginID) throws Exception {
		boolean isHashVaild = false;
		try {
			// #텍스트 파일 가져오기
			// 공유 노드(서버)의 체인 가져오기
			String serverBase62 = Base64Conversion.importChain("FTBC", Path.SERVER_CHAIN_PATH);
			System.out.println("서버 : \n"+serverBase62);
			this.serverChain = (BlockChain) Base64Conversion.decodeBase64(serverBase62);
			System.out.println("서버 체인의 사이즈 : "+serverChain.blockChain.size());
			// 클라이언트 체인 가져오기
			System.out.println("어디냐");
			String clientBase64 = Base64Conversion.importChain(loginID, Path.CLIENT_CHAIN_PATH);
			System.out.println("클라이언트 : \n"+clientBase64);
			this.clientChain = (BlockChain) Base64Conversion.decodeBase64(clientBase64);
			System.out.println("클라이언트 체인의 사이즈 : "+clientChain.blockChain.size());
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	public boolean isHashValid() throws Exception {
		boolean isValid = false;
		System.out.println("isValid0 : "+isValid);
		if(clientChain.isChainValid()) isValid = true;
		System.out.println("isValid1 : "+isValid);
		int clientChainSize = clientChain.blockChain.size();
		// 클라이언트 체인의 최신 블록의 해쉬값들을 비교
		Block clientBlock = clientChain.blockChain.get(clientChainSize-1);
		Block serverBlock = serverChain.blockChain.get(clientChainSize-1);
		System.out.println(clientBlock.hash+", "+serverBlock.hash);
		if(clientBlock.hash.equals(serverBlock.hash)) {
			isValid = true;
		} else {
			isValid = false;
		}
		System.out.println("isValid2 : "+isValid);
		System.out.println(clientBlock.previousHash+", "+serverBlock.previousHash);
		if(clientBlock.previousHash.equals(serverBlock.previousHash)) {
			isValid = true;
		} else {
			isValid = false;
		}
		System.out.println("isValid3 : "+isValid);
		return isValid;
	}
	
	public boolean isChainComparation(String loginID) throws Exception {
		int clientChainSize = clientChain.blockChain.size();
		int serverChainSize = serverChain.blockChain.size();
		if( (clientChainSize == serverChainSize) ) {
			return true;
		} else {
			for(int i=clientChainSize;i<serverChain.blockChain.size();i++) {
				Block block = serverChain.blockChain.get(i);
				clientChain.blockChain.add(block);
				clientChain.syncUTXOs();
				// 추가 된 클라이언트 체인 다운로드
				String clientBase64 = Base64Conversion.encodeChain(clientChain);
				Base64Conversion.saveChain(clientBase64, Path.CLIENT_CHAIN_PATH, loginID);
			}
			return false;
		}
	}
}
