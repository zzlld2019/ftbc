package blockchain;

import java.util.Map;

import blockchain.util.Base64Conversion;
import blockchain.util.CommonSet;

public class BringIt {
	BlockChain testChain = null;
	
	public void getProject() {
		
	}
	public BlockChain getChain() {
		try {
			String chain64 = Base64Conversion.importChain("FTBC","C:\\Users\\kosmo_03\\Desktop\\FTBC\\test (1)\\");
			System.out.println("chain64: " + chain64);
			testChain = (BlockChain)Base64Conversion.decodeBase64(chain64);
			System.out.println("testChain " + testChain);
			System.out.println("UTXOs " + testChain.UTXOs);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return testChain;
	}
	
	//체인 내에 UTXO에서 값 뽑아오기
	public void getUTXOs(BlockChain blockChain) {
		 Map<String, Output> UTXOs = blockChain.UTXOs;
		 Object[] keys = UTXOs.keySet().toArray();
		 System.out.println("keys " + keys);
		 System.out.println(keys.length);
		 
		 for(int i=0;i<keys.length;i++) {
			 System.out.println("key :" + keys[i]);
			 Output output = UTXOs.get(keys[i]);
			 //System.out.println("output: " + output);
			 System.out.println("Value: " + output.value);
			 System.out.println("recipient " + output.recipient);
		 }
	}
	
	//블록에 있는 트랜잭션 뽑아오기 
	public void getTxs(BlockChain blockChain) {
		System.out.println("GET TXs");
		Block block = null;
		Transaction transaction = null;
		for(int i=0;i<blockChain.blockChain.size();i++) {
			block = blockChain.blockChain.get(i);
			for(int j=0;j<block.transactions.size();j++){
				transaction = block.transactions.get(j);
				System.out.println("value " +transaction.value); //트랜잭션 밸류
				System.out.println("sender " +transaction.sender); //돈 보낸 사람 키
				System.out.println("reciepient " +transaction.reciepient); //돈 받은 사람 키 
			}
		}
	}
	
	public void getProjectBalance() {
		CommonSet commonset = CommonSet.getInstance();
		Map<String, Wallet> projectWallets = commonset.projectWallets;
		
	}
	public static void main(String[] args) {
		BringIt bringIt = new BringIt();
		BlockChain blockChain = bringIt.getChain();
		//bringIt.getUTXOs(blockChain);
		bringIt.getTxs(blockChain);
		
	}

}
