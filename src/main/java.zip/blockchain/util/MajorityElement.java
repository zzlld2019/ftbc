package blockchain.util;


import java.util.List;
import java.util.Vector;

import blockchain.BlockChain;


public class MajorityElement {
	
	// 두개의 체인이 같은지 비교하는 메소드
	// 두개의 체인의 해쉬와 이전 해쉬가 같은 경우 tre
	// 두개의 체인의 해쉬와 이전 해쉬가 다른 경우 false
	public boolean isChainEquals(BlockChain blockChain1, BlockChain blockChain2) {
		// 두 블록체인의 사이즈가 같다는 가정하에 진행
		// 두 블록체인의 클래스의 UTXOs의 사이즈도 같다는 가정하에 진행
		int size = blockChain1.blockChain.size();
		for(int i=0;i<size;i++) {
			String hash = blockChain1.blockChain.get(i).hash;
			String hash2 = blockChain2.blockChain.get(i).hash;
			String prehash = blockChain1.blockChain.get(i).previousHash;
			String prehash2 = blockChain2.blockChain.get(i).previousHash;
			if( (!hash.equals(hash2)) && (!prehash.equals(prehash2)) ) {
				return false;
			}
		}
		return true;
	}
	public BlockChain majorityElement(List<BlockChain> blockList) {
		BlockChain blockChain = null;
		int cnt = 0;
		int size = blockList.get(0).blockChain.size();
		for(int i=0;i<size;i++) {
			if(cnt==0) {
				blockChain = blockList.get(i);
				cnt++;
			} else if(isChainEquals(blockChain, blockList.get(i))) {
				cnt++;
			} else {
				cnt--;
			}
			System.out.println("isChainEquals : "+isChainEquals(blockChain, blockList.get(i)));
		}
		return blockChain;
		
	}
	/*
	public static void main(String[] args) {
		Test t = new Test();
		MajorityElement me = new MajorityElement();
		BlockChain blockChain1 = new BlockChain();
		t.server(blockChain1);
		BlockChain blockChain2 = blockChain1;
		BlockChain blockChain3 = blockChain1;
		List<BlockChain> blockList = new Vector<BlockChain>();
		blockList.add(blockChain1);
		blockList.add(blockChain2);
		blockList.add(blockChain3);
		System.out.println("blockChain1 : "+blockChain1);
		System.out.println("blockChain2 : "+blockChain2);
		System.out.println("blockChain3 : "+blockChain3);
		System.out.println(me.majorityElement(blockList));
	}
	*/
}
