package blockchain.util;

import java.security.PrivateKey;
import java.security.PublicKey;
import java.util.HashMap;
import java.util.Map;

import blockchain.Project;
import blockchain.Wallet;


public class CommonSet {
	/*
	 * 사용자의 지갑을 우리가 관리할 필요가 없다.
	 * 사용자가 개인키를 입력했을 때 지갑을 새로 생성해주면 된다.
	 */
	// public Map<String, Wallet> moneyWallets = new HashMap<>();
	public Map<String, Wallet> projectWallets = new HashMap<>();
	public Map<String, Project> projects = new HashMap<>();
	public Wallet managerWallet  = new Wallet();
	public byte b = 126;
	public long l = 1000000000000000000L;
	// 싱글톤
	private CommonSet() {}
	private static class LazyHolder {
	   public static final CommonSet INSTANCE = new CommonSet();
	}
	public static CommonSet getInstance() {
	   return LazyHolder.INSTANCE;
	}
	public Project getMyProject(String projectCode) throws Exception {
		Project myProject = null;
		for(int i=0;i<projects.size();i++) {
			Object keys[] = projects.keySet().toArray();
			if(projectCode.equals(keys[i])) {
				myProject = projects.get(keys[i]);
			}
		}
		return myProject;
	}
	public Wallet getProjectWallet(String walletID) throws Exception {
		Wallet projectWallet = null;
		System.out.println("getProjectWallet : "+walletID);
		System.out.println(projectWallets.get("박상범프로젝트지갑"));
		Object keys[] = projectWallets.keySet().toArray();
		for(int i=0;i<projectWallets.size();i++) {
			System.out.println(keys[i]);
			if(walletID.equals(keys[i])) {
				projectWallet = projectWallets.get(keys[i]);
			}
		}
		return projectWallet;
	}

	//매니저 지갑 키페어 생성
}
